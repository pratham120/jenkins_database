def config(){
    echo 'configuring the pipeline'
}

return this